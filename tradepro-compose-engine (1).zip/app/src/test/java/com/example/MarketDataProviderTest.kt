package com.example

import com.example.provider.RealMarketDataProvider
import com.example.provider.SimulatedMarketDataProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MarketDataProviderTest {

    @Test
    fun testSimulatedProviderDefaults() {
        val provider = SimulatedMarketDataProvider()
        assertFalse(provider.isLiveFeed)
        assertEquals("SIMULATED / DEMO DATA", provider.statusLabel)

        provider.registerAsset("EUR/USD", 1.08450)
        val price = provider.getCurrentPrice("EUR/USD")
        assertTrue(price > 0.0)

        val candles = provider.getCandles("EUR/USD", 5, 20)
        assertTrue(candles.isNotEmpty())
    }

    @Test
    fun testRealMarketDataProviderRegistration() {
        val provider = RealMarketDataProvider()
        val btcPrice = provider.getCurrentPrice("BTC/USD")
        assertTrue(btcPrice > 1000.0)

        val eurPrice = provider.getCurrentPrice("EUR/USD")
        assertTrue(eurPrice > 0.5 && eurPrice < 2.0)
    }
}
