package com.example

import com.example.engine.TradeSettlementEngine
import com.example.model.TradeDirection
import com.example.model.TradeStatus
import org.junit.Assert.assertEquals
import org.junit.Test

class TradeSettlementEngineTest {

    @Test
    fun testCallWin() {
        val result = TradeSettlementEngine.settleTrade(
            direction = TradeDirection.CALL,
            entryPrice = 1.08500,
            exitPrice = 1.08520,
            investmentAmount = 100.0,
            payoutRate = 0.90
        )
        assertEquals(TradeStatus.WON, result.status)
        assertEquals(90.0, result.profitLoss, 0.001)
        assertEquals(190.0, result.totalPayout, 0.001)
    }

    @Test
    fun testCallLoss() {
        val result = TradeSettlementEngine.settleTrade(
            direction = TradeDirection.CALL,
            entryPrice = 1.08500,
            exitPrice = 1.08480,
            investmentAmount = 100.0,
            payoutRate = 0.90
        )
        assertEquals(TradeStatus.LOST, result.status)
        assertEquals(-100.0, result.profitLoss, 0.001)
        assertEquals(0.0, result.totalPayout, 0.001)
    }

    @Test
    fun testPutWin() {
        val result = TradeSettlementEngine.settleTrade(
            direction = TradeDirection.PUT,
            entryPrice = 1.08500,
            exitPrice = 1.08450,
            investmentAmount = 200.0,
            payoutRate = 0.92
        )
        assertEquals(TradeStatus.WON, result.status)
        assertEquals(184.0, result.profitLoss, 0.001)
        assertEquals(384.0, result.totalPayout, 0.001)
    }

    @Test
    fun testPutLoss() {
        val result = TradeSettlementEngine.settleTrade(
            direction = TradeDirection.PUT,
            entryPrice = 1.08500,
            exitPrice = 1.08550,
            investmentAmount = 200.0,
            payoutRate = 0.92
        )
        assertEquals(TradeStatus.LOST, result.status)
        assertEquals(-200.0, result.profitLoss, 0.001)
        assertEquals(0.0, result.totalPayout, 0.001)
    }

    @Test
    fun testTieAtTheMoneyRefund() {
        val result = TradeSettlementEngine.settleTrade(
            direction = TradeDirection.CALL,
            entryPrice = 1.08500,
            exitPrice = 1.08500,
            investmentAmount = 150.0,
            payoutRate = 0.88
        )
        assertEquals(TradeStatus.TIE, result.status)
        assertEquals(0.0, result.profitLoss, 0.001)
        assertEquals(150.0, result.totalPayout, 0.001) // 100% investment refund
    }
}
