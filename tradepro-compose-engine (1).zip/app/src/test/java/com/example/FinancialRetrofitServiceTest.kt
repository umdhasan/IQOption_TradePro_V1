package com.example

import com.example.network.FinancialMarketRepository
import com.example.network.FinancialRetrofitClient
import com.example.network.model.FinnhubQuoteResponse
import com.example.network.model.OpenForexRatesResponse
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FinancialRetrofitServiceTest {

    @Test
    fun testRetrofitClientsNotNull() {
        assertNotNull(FinancialRetrofitClient.finnhubApi)
        assertNotNull(FinancialRetrofitClient.openForexApi)
        assertNotNull(FinancialRetrofitClient.binanceApi)
    }

    @Test
    fun testFinnhubQuoteDtoParsing() {
        val json = """
            {
                "c": 235.50,
                "d": 1.25,
                "dp": 0.53,
                "h": 236.00,
                "l": 234.10,
                "o": 234.50,
                "pc": 234.25,
                "t": 1729000000
            }
        """.trimIndent()

        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
        val adapter = moshi.adapter(FinnhubQuoteResponse::class.java)
        val quote = adapter.fromJson(json)

        assertNotNull(quote)
        assertEquals(235.50, quote?.currentPrice ?: 0.0, 0.001)
        assertEquals(1.25, quote?.change ?: 0.0, 0.001)
        assertEquals(0.53, quote?.percentChange ?: 0.0, 0.001)
    }

    @Test
    fun testOpenForexRatesDtoParsing() {
        val json = """
            {
                "result": "success",
                "base_code": "USD",
                "time_last_update_unix": 1729000000,
                "rates": {
                    "USD": 1.0,
                    "EUR": 0.9220,
                    "GBP": 0.7705,
                    "JPY": 153.25
                }
            }
        """.trimIndent()

        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
        val adapter = moshi.adapter(OpenForexRatesResponse::class.java)
        val response = adapter.fromJson(json)

        assertNotNull(response)
        assertEquals("success", response?.result)
        assertEquals(4, response?.rates?.size)
        assertEquals(153.25, response?.rates?.get("JPY") ?: 0.0, 0.001)
    }

    @Test
    fun testRepositoryInstantiation() {
        val repository = FinancialMarketRepository()
        assertNotNull(repository)
    }
}
