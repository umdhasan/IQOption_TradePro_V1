package com.example

import com.example.engine.MarketEngine
import com.example.model.ProductType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MarketProductTypeTest {

    @Test
    fun testProductTypesExistAndConfigured() {
        val types = ProductType.values()
        assertEquals(4, types.size)

        val names = types.map { it.displayName }
        assertTrue(names.contains("Digital"))
        assertTrue(names.contains("Binary"))
        assertTrue(names.contains("Forex"))
        assertTrue(names.contains("Blitz"))
    }

    @Test
    fun testDefaultAssetsForProducts() {
        val digitalAssets = MarketEngine.getDefaultAssets(ProductType.DIGITAL)
        assertTrue(digitalAssets.isNotEmpty())
        assertTrue(digitalAssets.any { it.symbol == "EUR/USD" })

        val blitzAssets = MarketEngine.getDefaultAssets(ProductType.BLITZ)
        assertTrue(blitzAssets.isNotEmpty())
        assertTrue(blitzAssets.all { it.productType == ProductType.BLITZ })
    }
}
