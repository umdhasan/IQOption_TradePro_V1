package com.example.engine

import java.util.Calendar
import java.util.TimeZone

object MarketSessionEngine {

    data class SessionInfo(
        val name: String,
        val region: String,
        val isOpen: Boolean,
        val volatility: String
    )

    fun getCurrentSessions(): List<SessionInfo> {
        val gmtCal = Calendar.getInstance(TimeZone.getTimeZone("GMT"))
        val gmtHour = gmtCal.get(Calendar.HOUR_OF_DAY)

        // London: 08:00 - 16:00 GMT
        val londonOpen = gmtHour in 8..16
        // New York: 13:00 - 21:00 GMT
        val newYorkOpen = gmtHour in 13..21
        // Tokyo: 00:00 - 09:00 GMT
        val tokyoOpen = gmtHour in 0..9
        // Sydney: 22:00 - 07:00 GMT
        val sydneyOpen = gmtHour >= 22 || gmtHour < 7

        return listOf(
            SessionInfo("London", "Europe", londonOpen, if (londonOpen) "High" else "Low"),
            SessionInfo("New York", "Americas", newYorkOpen, if (newYorkOpen) "Very High" else "Low"),
            SessionInfo("Tokyo", "Asia-Pacific", tokyoOpen, if (tokyoOpen) "Medium" else "Low"),
            SessionInfo("Sydney", "Pacific", sydneyOpen, if (sydneyOpen) "Medium" else "Low")
        )
    }

    fun getActiveSessionSummary(): String {
        val open = getCurrentSessions().filter { it.isOpen }.map { it.name }
        return if (open.isNotEmpty()) "Open: ${open.joinToString(", ")}" else "Asian Pre-Market (Simulated 24/7)"
    }
}
