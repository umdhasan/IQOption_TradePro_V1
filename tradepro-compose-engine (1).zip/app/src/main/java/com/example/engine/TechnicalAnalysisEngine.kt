package com.example.engine

import com.example.model.Candle
import kotlin.math.sqrt

object TechnicalAnalysisEngine {

    data class BollingerBands(
        val upper: Double,
        val middle: Double,
        val lower: Double
    )

    data class MacdResult(
        val macd: Double,
        val signal: Double,
        val histogram: Double
    )

    fun calculateSMA(prices: List<Double>, period: Int): List<Double> {
        if (prices.size < period || period <= 0) return emptyList()
        val result = mutableListOf<Double>()
        var sum = 0.0
        for (i in 0 until period) {
            sum += prices[i]
        }
        result.add(sum / period)

        for (i in period until prices.size) {
            sum += prices[i] - prices[i - period]
            result.add(sum / period)
        }
        return result
    }

    fun calculateEMA(prices: List<Double>, period: Int): List<Double> {
        if (prices.size < period || period <= 0) return emptyList()
        val multiplier = 2.0 / (period + 1)
        val result = mutableListOf<Double>()

        // First EMA is SMA of first 'period' elements
        var sum = 0.0
        for (i in 0 until period) {
            sum += prices[i]
        }
        var prevEma = sum / period
        result.add(prevEma)

        for (i in period until prices.size) {
            val currentEma = (prices[i] - prevEma) * multiplier + prevEma
            result.add(currentEma)
            prevEma = currentEma
        }
        return result
    }

    fun calculateRSI(candles: List<Candle>, period: Int = 14): Double {
        if (candles.size < period + 1) return 50.0

        val closes = candles.map { it.close }
        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val change = closes[i] - closes[i - 1]
            if (change > 0) gains += change else losses += -change
        }

        var avgGain = gains / period
        var avgLoss = losses / period

        for (i in (period + 1) until closes.size) {
            val change = closes[i] - closes[i - 1]
            val gain = if (change > 0) change else 0.0
            val loss = if (change < 0) -change else 0.0

            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
        }

        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    fun calculateBollingerBands(candles: List<Candle>, period: Int = 20, multiplier: Double = 2.0): BollingerBands? {
        if (candles.size < period) return null
        val recentCloses = candles.takeLast(period).map { it.close }
        val mean = recentCloses.average()
        val variance = recentCloses.map { (it - mean) * (it - mean) }.average()
        val stdDev = sqrt(variance)

        return BollingerBands(
            upper = mean + (multiplier * stdDev),
            middle = mean,
            lower = mean - (multiplier * stdDev)
        )
    }

    fun calculateMACD(candles: List<Candle>): MacdResult? {
        val closes = candles.map { it.close }
        if (closes.size < 35) return null

        val ema12 = calculateEMA(closes, 12)
        val ema26 = calculateEMA(closes, 26)

        val macdLine = mutableListOf<Double>()
        val offset = ema12.size - ema26.size
        for (i in ema26.indices) {
            macdLine.add(ema12[i + offset] - ema26[i])
        }

        val signalLine = calculateEMA(macdLine, 9)
        if (signalLine.isEmpty()) return null

        val latestMacd = macdLine.last()
        val latestSignal = signalLine.last()
        return MacdResult(
            macd = latestMacd,
            signal = latestSignal,
            histogram = latestMacd - latestSignal
        )
    }
}
