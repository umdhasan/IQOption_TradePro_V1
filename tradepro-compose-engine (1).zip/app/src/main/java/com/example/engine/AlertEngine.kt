package com.example.engine

import com.example.model.Alert
import com.example.model.AlertCondition

object AlertEngine {

    fun checkAlerts(alerts: List<Alert>, assetSymbol: String, currentPrice: Double): List<Alert> {
        val triggered = mutableListOf<Alert>()

        for (alert in alerts) {
            if (!alert.isTriggered && alert.assetSymbol == assetSymbol) {
                val isTriggered = when (alert.condition) {
                    AlertCondition.ABOVE -> currentPrice >= alert.targetPrice
                    AlertCondition.BELOW -> currentPrice <= alert.targetPrice
                }
                if (isTriggered) {
                    triggered.add(alert.copy(isTriggered = true))
                }
            }
        }
        return triggered
    }
}
