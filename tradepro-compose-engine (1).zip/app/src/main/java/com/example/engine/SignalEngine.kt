package com.example.engine

import com.example.model.Asset
import com.example.model.Candle
import com.example.model.ProductType
import com.example.model.Signal
import com.example.model.TradeDirection
import java.util.UUID

object SignalEngine {

    fun generateSignal(asset: Asset, candles: List<Candle>, timeframe: String = "1m"): Signal? {
        if (candles.size < 25) return null

        val rsi = TechnicalAnalysisEngine.calculateRSI(candles)
        val macd = TechnicalAnalysisEngine.calculateMACD(candles)
        val bb = TechnicalAnalysisEngine.calculateBollingerBands(candles)
        val currentPrice = candles.last().close

        var callScore = 0
        var putScore = 0
        val reasons = mutableListOf<String>()

        // RSI scoring
        if (rsi <= 30.0) {
            callScore += 35
            reasons.add("RSI Oversold (%.1f)".format(rsi))
        } else if (rsi >= 70.0) {
            putScore += 35
            reasons.add("RSI Overbought (%.1f)".format(rsi))
        }

        // Bollinger Bands scoring
        bb?.let { bands ->
            if (currentPrice <= bands.lower) {
                callScore += 30
                reasons.add("Price bounced off lower Bollinger Band")
            } else if (currentPrice >= bands.upper) {
                putScore += 30
                reasons.add("Price rejected at upper Bollinger Band")
            }
        }

        // MACD scoring
        macd?.let { m ->
            if (m.histogram > 0 && m.macd > m.signal) {
                callScore += 25
                reasons.add("MACD Bullish Crossover")
            } else if (m.histogram < 0 && m.macd < m.signal) {
                putScore += 25
                reasons.add("MACD Bearish Crossover")
            }
        }

        // Trend momentum
        val closes = candles.takeLast(5).map { it.close }
        val shortTermUp = closes.last() > closes.first()
        if (shortTermUp) callScore += 10 else putScore += 10

        val (direction, rawScore) = if (callScore > putScore) {
            TradeDirection.CALL to callScore
        } else {
            TradeDirection.PUT to putScore
        }

        if (rawScore < 45) return null

        val confidence = (65 + (rawScore * 0.3)).toInt().coerceIn(70, 95)
        val reasonText = if (reasons.isNotEmpty()) reasons.joinToString(" • ") else "Technical Trend Alignment"

        return Signal(
            id = UUID.randomUUID().toString(),
            assetSymbol = asset.symbol,
            productType = asset.productType,
            direction = direction,
            confidence = confidence,
            timeframe = timeframe,
            reason = reasonText,
            timestamp = System.currentTimeMillis()
        )
    }
}
