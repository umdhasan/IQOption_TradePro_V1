package com.example.engine

import com.example.model.Trade
import com.example.model.TradeDirection
import com.example.model.TradeStatus
import kotlin.math.abs

object TradeSettlementEngine {

    data class SettlementResult(
        val status: TradeStatus,
        val profitLoss: Double,
        val totalPayout: Double,
        val exitPrice: Double
    )

    private const val EPSILON = 0.0000001

    fun settleTrade(
        direction: TradeDirection,
        entryPrice: Double,
        exitPrice: Double,
        investmentAmount: Double,
        payoutRate: Double
    ): SettlementResult {
        val diff = exitPrice - entryPrice
        val isTie = abs(diff) < EPSILON

        val status = when {
            isTie -> TradeStatus.TIE
            direction == TradeDirection.CALL -> if (diff > 0) TradeStatus.WON else TradeStatus.LOST
            direction == TradeDirection.PUT -> if (diff < 0) TradeStatus.WON else TradeStatus.LOST
            else -> TradeStatus.TIE
        }

        val profitLoss = when (status) {
            TradeStatus.WON -> investmentAmount * payoutRate
            TradeStatus.LOST -> -investmentAmount
            TradeStatus.TIE -> 0.0
            TradeStatus.OPEN -> 0.0
        }

        val totalPayout = when (status) {
            TradeStatus.WON -> investmentAmount + profitLoss
            TradeStatus.LOST -> 0.0
            TradeStatus.TIE -> investmentAmount // 100% refund on tie (At The Money)
            TradeStatus.OPEN -> 0.0
        }

        return SettlementResult(
            status = status,
            profitLoss = profitLoss,
            totalPayout = totalPayout,
            exitPrice = exitPrice
        )
    }

    fun settleTrade(trade: Trade, exitPrice: Double): Trade {
        val result = settleTrade(
            direction = trade.direction,
            entryPrice = trade.entryPrice,
            exitPrice = exitPrice,
            investmentAmount = trade.investmentAmount,
            payoutRate = trade.payoutRate
        )

        return trade.copy(
            status = result.status,
            exitPrice = result.exitPrice,
            profitLoss = result.profitLoss
        )
    }
}
