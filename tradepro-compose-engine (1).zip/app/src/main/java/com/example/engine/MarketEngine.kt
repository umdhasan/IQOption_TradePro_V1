package com.example.engine

import com.example.model.Asset
import com.example.model.ProductType

object MarketEngine {

    fun getDefaultAssets(productType: ProductType): List<Asset> {
        return when (productType) {
            ProductType.DIGITAL -> listOf(
                Asset("EUR/USD", "Euro / US Dollar", ProductType.DIGITAL, 1.08450, 0.35, 1.08720, 1.08210, 0.92, "Currencies"),
                Asset("GBP/USD", "British Pound / US Dollar", ProductType.DIGITAL, 1.29820, -0.18, 1.30250, 1.29540, 0.90, "Currencies"),
                Asset("USD/JPY", "US Dollar / Japanese Yen", ProductType.DIGITAL, 153.250, 0.62, 153.800, 152.400, 0.91, "Currencies"),
                Asset("BTC/USD", "Bitcoin / US Dollar", ProductType.DIGITAL, 82000.0, 2.45, 83500.0, 80800.0, 0.95, "Crypto"),
                Asset("ETH/USD", "Ethereum / US Dollar", ProductType.DIGITAL, 2460.50, 1.80, 2520.00, 2410.00, 0.93, "Crypto"),
                Asset("AAPL/USD", "Apple Inc. (Stock)", ProductType.DIGITAL, 235.50, 0.65, 237.20, 234.10, 0.90, "Stocks"),
                Asset("TSLA/USD", "Tesla Inc. (Stock)", ProductType.DIGITAL, 220.80, -1.20, 224.50, 218.00, 0.89, "Stocks"),
                Asset("NVDA/USD", "Nvidia Corp. (Stock)", ProductType.DIGITAL, 138.20, 3.10, 140.50, 135.00, 0.92, "Stocks"),
                Asset("XAU/USD", "Gold / US Dollar", ProductType.DIGITAL, 2735.80, 0.85, 2748.20, 2715.40, 0.90, "Commodities")
            )
            ProductType.BINARY -> listOf(
                Asset("EUR/USD", "Euro / US Dollar", ProductType.BINARY, 1.08450, 0.35, 1.08720, 1.08210, 0.88, "Currencies"),
                Asset("GBP/JPY", "British Pound / Yen", ProductType.BINARY, 198.900, 0.45, 199.500, 198.100, 0.87, "Currencies"),
                Asset("AUD/USD", "Australian Dollar / USD", ProductType.BINARY, 0.66250, -0.42, 0.66700, 0.66100, 0.86, "Currencies"),
                Asset("USD/CAD", "US Dollar / Canadian Dollar", ProductType.BINARY, 1.38500, 0.15, 1.38900, 1.38200, 0.85, "Currencies"),
                Asset("USD/CHF", "US Dollar / Swiss Franc", ProductType.BINARY, 0.86650, -0.10, 0.86900, 0.86400, 0.86, "Currencies"),
                Asset("AAPL/USD", "Apple Inc. (Stock)", ProductType.BINARY, 235.50, 0.65, 237.20, 234.10, 0.86, "Stocks"),
                Asset("NVDA/USD", "Nvidia Corp. (Stock)", ProductType.BINARY, 138.20, 3.10, 140.50, 135.00, 0.87, "Stocks"),
                Asset("XAU/USD", "Gold / US Dollar", ProductType.BINARY, 2735.80, 0.85, 2748.20, 2715.40, 0.89, "Commodities")
            )
            ProductType.FOREX -> listOf(
                Asset("EUR/USD", "Euro / US Dollar", ProductType.FOREX, 1.08450, 0.35, 1.08720, 1.08210, 0.82, "Currencies"),
                Asset("GBP/USD", "British Pound / US Dollar", ProductType.FOREX, 1.29820, -0.18, 1.30250, 1.29540, 0.80, "Currencies"),
                Asset("USD/JPY", "US Dollar / Japanese Yen", ProductType.FOREX, 153.250, 0.62, 153.800, 152.400, 0.82, "Currencies"),
                Asset("NZD/USD", "New Zealand Dollar / USD", ProductType.FOREX, 0.59950, -0.55, 0.60400, 0.59800, 0.78, "Currencies"),
                Asset("EUR/GBP", "Euro / British Pound", ProductType.FOREX, 0.83540, 0.28, 0.83850, 0.83300, 0.81, "Currencies"),
                Asset("USD/MXN", "US Dollar / Mexican Peso", ProductType.FOREX, 19.850, 0.72, 20.050, 19.680, 0.77, "Currencies")
            )
            ProductType.BLITZ -> listOf(
                Asset("EUR/USD", "Euro / US Dollar (Turbo)", ProductType.BLITZ, 1.08450, 0.35, 1.08720, 1.08210, 0.95, "Currencies"),
                Asset("GBP/USD", "British Pound / USD (Turbo)", ProductType.BLITZ, 1.29820, -0.18, 1.30250, 1.29540, 0.95, "Currencies"),
                Asset("BTC/USD", "Bitcoin Blitz", ProductType.BLITZ, 82000.0, 2.45, 83500.0, 80800.0, 0.96, "Crypto"),
                Asset("USD/JPY", "US Dollar / Yen (Turbo)", ProductType.BLITZ, 153.250, 0.62, 153.800, 152.400, 0.94, "Currencies"),
                Asset("SOL/USD", "Solana Blitz", ProductType.BLITZ, 106.00, 4.12, 110.50, 102.00, 0.95, "Crypto"),
                Asset("ETH/USD", "Ethereum Blitz", ProductType.BLITZ, 2460.50, 1.80, 2520.00, 2410.00, 0.94, "Crypto")
            )
        }
    }
}
