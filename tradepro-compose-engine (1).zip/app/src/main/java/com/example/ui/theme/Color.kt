package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Terminal dark palette
val DarkNavyBackground = Color(0xFF090E17)
val DarkNavySurface = Color(0xFF111927)
val DarkNavySurfaceVariant = Color(0xFF1A2436)
val DarkNavyOutline = Color(0xFF26354D)

// Trading indicators & actions
val TradeBullGreen = Color(0xFF00E676)
val TradeBullGreenDark = Color(0xFF00B359)
val TradeBearRed = Color(0xFFFF3366)
val TradeBearRedDark = Color(0xFFCC1F49)

val AccentCyan = Color(0xFF00E5FF)
val AccentGold = Color(0xFFFFB300)
val AccentPurple = Color(0xFF7C4DFF)

// Text colors
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Demo status colors
val DemoBadgeBg = Color(0xFF2D2006)
val DemoBadgeText = Color(0xFFFFB800)
val DemoBadgeBorder = Color(0xFF855D00)
