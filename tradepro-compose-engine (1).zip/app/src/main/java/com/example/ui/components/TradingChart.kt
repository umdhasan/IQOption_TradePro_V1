package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.TechnicalAnalysisEngine
import com.example.model.Candle
import com.example.model.Trade
import com.example.model.TradeDirection
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.DarkNavyBackground
import com.example.ui.theme.DarkNavyOutline
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TradeBearRed
import com.example.ui.theme.TradeBullGreen
import kotlin.math.max
import kotlin.math.min

enum class ChartType {
    CANDLESTICK, AREA
}

@Composable
fun TradingChart(
    candles: List<Candle>,
    currentPrice: Double,
    activeTrades: List<Trade>,
    chartType: ChartType = ChartType.CANDLESTICK,
    showSma: Boolean = true,
    showEma: Boolean = true,
    showBollingerBands: Boolean = false,
    modifier: Modifier = Modifier
) {
    if (candles.isEmpty()) {
        Box(
            modifier = modifier
                .background(DarkNavyBackground)
                .fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("Loading market data...", color = TextMuted)
        }
        return
    }

    var selectedCandle by remember { mutableStateOf<Candle?>(null) }
    var tapOffset by remember { mutableStateOf<Offset?>(null) }

    Box(modifier = modifier.background(DarkNavyBackground)) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(candles) {
                    detectTapGestures(
                        onTap = { offset ->
                            tapOffset = offset
                            val width = size.width - 65.dp.toPx()
                            val candleWidth = width / candles.size
                            val index = (offset.x / candleWidth).toInt().coerceIn(0, candles.lastIndex)
                            selectedCandle = candles[index]
                        }
                    )
                }
        ) {
            val chartRightMargin = 65.dp.toPx()
            val chartBottomMargin = 20.dp.toPx()
            val availableWidth = size.width - chartRightMargin
            val availableHeight = size.height - chartBottomMargin

            val visibleCandles = candles.takeLast(60)
            if (visibleCandles.isEmpty()) return@Canvas

            var minPrice = visibleCandles.minOf { it.low }
            var maxPrice = visibleCandles.maxOf { it.high }

            // Ensure current price and active trades fit in view
            minPrice = min(minPrice, currentPrice)
            maxPrice = max(maxPrice, currentPrice)
            activeTrades.forEach {
                minPrice = min(minPrice, it.entryPrice)
                maxPrice = max(maxPrice, it.entryPrice)
            }

            // Margin padding on price scale
            val priceSpan = maxPrice - minPrice
            val pricePadding = if (priceSpan > 0) priceSpan * 0.1 else maxPrice * 0.01
            val effectiveMin = (minPrice - pricePadding).coerceAtLeast(0.00001)
            val effectiveMax = maxPrice + pricePadding
            val effectiveSpan = (effectiveMax - effectiveMin).coerceAtLeast(0.00001)

            fun priceToY(price: Double): Float {
                val ratio = (price - effectiveMin) / effectiveSpan
                return (availableHeight - (ratio * availableHeight)).toFloat()
            }

            // Draw grid lines
            drawGrid(availableWidth, availableHeight, effectiveMin, effectiveSpan)

            val candleWidth = availableWidth / visibleCandles.size
            val candleSpacing = candleWidth * 0.2f
            val bodyWidth = (candleWidth - candleSpacing).coerceAtLeast(2f)

            if (chartType == ChartType.CANDLESTICK) {
                // Draw Candlesticks
                visibleCandles.forEachIndexed { index, candle ->
                    val xCenter = (index * candleWidth) + (candleWidth / 2f)
                    val isBullish = candle.close >= candle.open
                    val candleColor = if (isBullish) TradeBullGreen else TradeBearRed

                    val highY = priceToY(candle.high)
                    val lowY = priceToY(candle.low)
                    val openY = priceToY(candle.open)
                    val closeY = priceToY(candle.close)

                    // Wick
                    drawLine(
                        color = candleColor,
                        start = Offset(xCenter, highY),
                        end = Offset(xCenter, lowY),
                        strokeWidth = 1.5f
                    )

                    // Body
                    val bodyTop = min(openY, closeY)
                    val bodyHeight = max(kotlin.math.abs(closeY - openY), 2f)
                    val bodyLeft = xCenter - (bodyWidth / 2f)

                    drawRect(
                        color = candleColor,
                        topLeft = Offset(bodyLeft, bodyTop),
                        size = Size(bodyWidth, bodyHeight),
                        style = Fill
                    )
                }
            } else {
                // Area Chart
                val areaPath = Path()
                val linePath = Path()

                visibleCandles.forEachIndexed { index, candle ->
                    val x = (index * candleWidth) + (candleWidth / 2f)
                    val y = priceToY(candle.close)
                    if (index == 0) {
                        linePath.moveTo(x, y)
                        areaPath.moveTo(x, availableHeight)
                        areaPath.lineTo(x, y)
                    } else {
                        linePath.lineTo(x, y)
                        areaPath.lineTo(x, y)
                    }
                    if (index == visibleCandles.lastIndex) {
                        areaPath.lineTo(x, availableHeight)
                        areaPath.close()
                    }
                }

                drawPath(
                    path = areaPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(AccentCyan.copy(alpha = 0.35f), AccentCyan.copy(alpha = 0.02f)),
                        startY = 0f,
                        endY = availableHeight
                    )
                )
                drawPath(
                    path = linePath,
                    color = AccentCyan,
                    style = Stroke(width = 2.5f)
                )
            }

            // SMA Overlay (Period 9)
            if (showSma) {
                val closes = visibleCandles.map { it.close }
                val smaList = TechnicalAnalysisEngine.calculateSMA(closes, 9)
                val offset = visibleCandles.size - smaList.size
                if (smaList.isNotEmpty()) {
                    val smaPath = Path()
                    smaList.forEachIndexed { i, value ->
                        val x = ((i + offset) * candleWidth) + (candleWidth / 2f)
                        val y = priceToY(value)
                        if (i == 0) smaPath.moveTo(x, y) else smaPath.lineTo(x, y)
                    }
                    drawPath(
                        path = smaPath,
                        color = AccentGold,
                        style = Stroke(width = 2f)
                    )
                }
            }

            // EMA Overlay (Period 21)
            if (showEma) {
                val closes = visibleCandles.map { it.close }
                val emaList = TechnicalAnalysisEngine.calculateEMA(closes, 21)
                val offset = visibleCandles.size - emaList.size
                if (emaList.isNotEmpty()) {
                    val emaPath = Path()
                    emaList.forEachIndexed { i, value ->
                        val x = ((i + offset) * candleWidth) + (candleWidth / 2f)
                        val y = priceToY(value)
                        if (i == 0) emaPath.moveTo(x, y) else emaPath.lineTo(x, y)
                    }
                    drawPath(
                        path = emaPath,
                        color = AccentCyan,
                        style = Stroke(width = 2f)
                    )
                }
            }

            // Draw Active Trade Entry Markers
            activeTrades.forEach { trade ->
                val tradeY = priceToY(trade.entryPrice)
                val isCall = trade.direction == TradeDirection.CALL
                val tradeColor = if (isCall) TradeBullGreen else TradeBearRed

                drawLine(
                    color = tradeColor,
                    start = Offset(0f, tradeY),
                    end = Offset(availableWidth, tradeY),
                    strokeWidth = 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )

                // Trade badge on line
                drawRect(
                    color = tradeColor,
                    topLeft = Offset(10.dp.toPx(), tradeY - 10.dp.toPx()),
                    size = Size(80.dp.toPx(), 20.dp.toPx())
                )

                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        color = android.graphics.Color.WHITE
                        textSize = 30f
                        isFakeBoldText = true
                    }
                    val label = "${trade.direction.name} $${trade.investmentAmount.toInt()} (${trade.remainingSeconds}s)"
                    drawText(label, 15.dp.toPx(), tradeY + 4.dp.toPx(), paint)
                }
            }

            // Current Market Price Line
            val currentY = priceToY(currentPrice)
            drawLine(
                color = AccentCyan,
                start = Offset(0f, currentY),
                end = Offset(availableWidth, currentY),
                strokeWidth = 2f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
            )

            // Current price pulse dot
            drawCircle(
                color = AccentCyan,
                radius = 5.dp.toPx(),
                center = Offset(availableWidth, currentY)
            )

            // Price label on right axis
            val priceLabelWidth = chartRightMargin - 4.dp.toPx()
            drawRect(
                color = AccentCyan,
                topLeft = Offset(availableWidth + 4.dp.toPx(), currentY - 11.dp.toPx()),
                size = Size(priceLabelWidth, 22.dp.toPx())
            )

            drawContext.canvas.nativeCanvas.apply {
                val paint = android.graphics.Paint().apply {
                    color = android.graphics.Color.BLACK
                    textSize = 28f
                    isFakeBoldText = true
                }
                val formattedPrice = if (currentPrice >= 100) "%.2f".format(currentPrice) else "%.5f".format(currentPrice)
                drawText(formattedPrice, availableWidth + 8.dp.toPx(), currentY + 5.dp.toPx(), paint)
            }
        }

        // Tap inspection overlay tooltip
        selectedCandle?.let { candle ->
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .background(DarkNavyOutline.copy(alpha = 0.9f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "O: ${"%.5f".format(candle.open)}  H: ${"%.5f".format(candle.high)}  L: ${"%.5f".format(candle.low)}  C: ${"%.5f".format(candle.close)}",
                    color = TextPrimary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

private fun DrawScope.drawGrid(
    width: Float,
    height: Float,
    effectiveMin: Double,
    effectiveSpan: Double
) {
    val horizontalGridLines = 4
    for (i in 0..horizontalGridLines) {
        val y = height * (i.toFloat() / horizontalGridLines)
        drawLine(
            color = DarkNavyOutline,
            start = Offset(0f, y),
            end = Offset(width, y),
            strokeWidth = 1f
        )

        val price = effectiveMin + (effectiveSpan * (1f - (i.toFloat() / horizontalGridLines)))
        drawContext.canvas.nativeCanvas.apply {
            val paint = android.graphics.Paint().apply {
                color = android.graphics.Color.GRAY
                textSize = 24f
            }
            val priceStr = if (price >= 100) "%.2f".format(price) else "%.5f".format(price)
            drawText(priceStr, width + 6.dp.toPx(), y + 8f, paint)
        }
    }
}
