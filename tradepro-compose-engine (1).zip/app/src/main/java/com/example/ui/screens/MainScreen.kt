package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.IntegrationInstructions
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TradeProViewModel
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.DarkNavyBackground
import com.example.ui.theme.DarkNavyOutline
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.TextMuted

enum class AppNavDestination(val label: String, val icon: ImageVector) {
    TERMINAL("Terminal", Icons.Default.TrendingUp),
    MARKETS("Markets", Icons.Default.ShowChart),
    SIGNALS("Signals", Icons.Default.AutoAwesome),
    ALERTS("Alerts", Icons.Default.Notifications),
    HISTORY("History", Icons.Default.History),
    SCRIPTS("Scripts", Icons.Default.IntegrationInstructions)
}

@Composable
fun MainScreen(
    viewModel: TradeProViewModel,
    modifier: Modifier = Modifier
) {
    var currentDestination by rememberSaveable { mutableStateOf(AppNavDestination.TERMINAL) }

    // Predictive back handler to return to Terminal if on a secondary screen
    BackHandler(enabled = currentDestination != AppNavDestination.TERMINAL) {
        currentDestination = AppNavDestination.TERMINAL
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = DarkNavyBackground,
        bottomBar = {
            NavigationBar(
                containerColor = DarkNavySurface,
                tonalElevation = 0.dp
            ) {
                AppNavDestination.values().forEach { destination ->
                    val isSelected = destination == currentDestination
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentDestination = destination },
                        icon = {
                            Icon(
                                imageVector = destination.icon,
                                contentDescription = destination.label,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = destination.label,
                                fontSize = 10.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DarkNavyBackground,
                            selectedTextColor = AccentCyan,
                            indicatorColor = AccentCyan,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        val screenModifier = Modifier.padding(innerPadding)
        when (currentDestination) {
            AppNavDestination.TERMINAL -> TerminalScreen(viewModel = viewModel, modifier = screenModifier)
            AppNavDestination.MARKETS -> MarketsScreen(
                viewModel = viewModel,
                onNavigateToTerminal = { currentDestination = AppNavDestination.TERMINAL },
                modifier = screenModifier
            )
            AppNavDestination.SIGNALS -> SignalBotScreen(
                viewModel = viewModel,
                onNavigateToTerminal = { currentDestination = AppNavDestination.TERMINAL },
                modifier = screenModifier
            )
            AppNavDestination.ALERTS -> AlertsScreen(viewModel = viewModel, modifier = screenModifier)
            AppNavDestination.HISTORY -> HistoryScreen(viewModel = viewModel, modifier = screenModifier)
            AppNavDestination.SCRIPTS -> TradingScriptsTab(modifier = screenModifier)
        }
    }
}
