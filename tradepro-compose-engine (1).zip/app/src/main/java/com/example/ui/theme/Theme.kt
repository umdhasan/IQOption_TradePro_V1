package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TerminalDarkColorScheme = darkColorScheme(
    primary = AccentCyan,
    onPrimary = Color.Black,
    primaryContainer = DarkNavySurfaceVariant,
    onPrimaryContainer = AccentCyan,
    secondary = TradeBullGreen,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF00381B),
    onSecondaryContainer = TradeBullGreen,
    tertiary = AccentGold,
    onTertiary = Color.Black,
    error = TradeBearRed,
    onError = Color.White,
    background = DarkNavyBackground,
    onBackground = TextPrimary,
    surface = DarkNavySurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkNavySurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkNavyOutline
)

@Composable
fun TradeProTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Trading terminals are predominantly dark mode for clarity and high-contrast chart rendering
    MaterialTheme(
        colorScheme = TerminalDarkColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    TradeProTheme(darkTheme = true, content = content)
}
