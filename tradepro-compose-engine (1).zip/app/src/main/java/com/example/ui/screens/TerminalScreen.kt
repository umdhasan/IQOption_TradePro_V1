package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Asset
import com.example.model.ProductType
import com.example.model.TimeFrame
import com.example.model.TradeDirection
import com.example.ui.TradeProViewModel
import com.example.ui.components.ChartType
import com.example.ui.components.IndicatorsView
import com.example.ui.components.PriceSyncDialog
import com.example.ui.components.TradingChart
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.DarkNavyBackground
import com.example.ui.theme.DarkNavyOutline
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.DarkNavySurfaceVariant
import com.example.ui.theme.DemoBadgeBg
import com.example.ui.theme.DemoBadgeBorder
import com.example.ui.theme.DemoBadgeText
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TradeBearRed
import com.example.ui.theme.TradeBullGreen

@Composable
fun TerminalScreen(
    viewModel: TradeProViewModel,
    modifier: Modifier = Modifier
) {
    val demoBalance by viewModel.demoBalance.collectAsState()
    val activeProductType by viewModel.activeProductType.collectAsState()
    val assets by viewModel.assets.collectAsState()
    val selectedAsset by viewModel.selectedAsset.collectAsState()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsState()
    val investmentAmount by viewModel.investmentAmount.collectAsState()
    val currentPrice by viewModel.currentPrice.collectAsState()
    val candles by viewModel.candles.collectAsState()
    val activeTrades by viewModel.activeTrades.collectAsState()
    val showSma by viewModel.showSma.collectAsState()
    val showEma by viewModel.showEma.collectAsState()
    val chartType by viewModel.chartType.collectAsState()
    val rsiValue by viewModel.rsiValue.collectAsState()
    val macdValue by viewModel.macdValue.collectAsState()

    var showBalanceResetDialog by remember { mutableStateOf(false) }

    if (showBalanceResetDialog) {
        PriceSyncDialog(
            currentBalance = demoBalance,
            onResetBalance = { viewModel.resetDemoBalance(it) },
            onDismiss = { showBalanceResetDialog = false }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBackground)
    ) {
        // TOP HEADER: SIMULATED / DEMO DATA BADGE & DEMO ACCOUNT
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkNavySurface)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Market Feed Status Badge (Live vs Simulated)
            val isLive = viewModel.isLiveFeed
            val badgeBg = if (isLive) Color(0xFF00381B) else DemoBadgeBg
            val badgeBorder = if (isLive) TradeBullGreen else DemoBadgeBorder
            val badgeColor = if (isLive) TradeBullGreen else DemoBadgeText
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(badgeBg)
                    .border(1.dp, badgeBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(badgeColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = viewModel.statusLabel,
                        color = badgeColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Demo Balance & Reset
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkNavySurfaceVariant)
                    .clickable { showBalanceResetDialog = true }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AccountBalanceWallet,
                    contentDescription = "Demo Account",
                    tint = TradeBullGreen,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "DEMO ACCOUNT",
                        color = TextMuted,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "$${"%,.2f".format(demoBalance)}",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reset Demo Balance",
                    tint = TextMuted,
                    modifier = Modifier.size(14.dp)
                )
            }
        }

        // FOUR PRODUCT TABS: Digital, Binary, Forex, Blitz
        TabRow(
            selectedTabIndex = activeProductType.ordinal,
            containerColor = DarkNavySurface,
            contentColor = AccentCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[activeProductType.ordinal]),
                    color = AccentCyan,
                    height = 2.5.dp
                )
            },
            divider = {}
        ) {
            ProductType.values().forEach { product ->
                val selected = product == activeProductType
                Tab(
                    selected = selected,
                    onClick = { viewModel.setProductType(product) },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = product.displayName,
                                fontSize = 13.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                color = if (selected) AccentCyan else TextSecondary
                            )
                            if (product == ProductType.BLITZ) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(AccentGold)
                                        .padding(horizontal = 3.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = "TURBO",
                                        color = Color.Black,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }
                    }
                )
            }
        }

        // ASSET SELECTOR SCROLL BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkNavyBackground)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            assets.forEach { asset ->
                val isSelected = asset.symbol == selectedAsset.symbol
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) DarkNavySurfaceVariant else DarkNavySurface,
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, AccentCyan) else null,
                    modifier = Modifier.clickable { viewModel.selectAsset(asset) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = asset.symbol,
                                color = if (isSelected) AccentCyan else TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${(asset.payoutRate * 100).toInt()}% payout",
                                color = TradeBullGreen,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        // CHART CONTROLS BAR: TIMEFRAMES, CHART TYPE & INDICATORS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkNavySurface)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Timeframe Selector Chips
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                TimeFrame.ALL.forEach { tf ->
                    val isSelected = tf.seconds == selectedTimeframe.seconds
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) AccentCyan.copy(alpha = 0.25f) else Color.Transparent)
                            .clickable { viewModel.selectTimeframe(tf) }
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = tf.label,
                            color = if (isSelected) AccentCyan else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }

            // Chart Type Toggle Button
            IconButton(
                onClick = { viewModel.toggleChartType() },
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = if (chartType == ChartType.CANDLESTICK) Icons.Default.Timeline else Icons.Default.ShowChart,
                    contentDescription = "Toggle Chart Type",
                    tint = AccentCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // INDICATORS BAR
        IndicatorsView(
            showSma = showSma,
            onToggleSma = { viewModel.toggleSma() },
            showEma = showEma,
            onToggleEma = { viewModel.toggleEma() },
            rsiValue = rsiValue,
            macdValue = macdValue
        )

        // MAIN TRADING CHART CANVAS
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            TradingChart(
                candles = candles,
                currentPrice = currentPrice,
                activeTrades = activeTrades,
                chartType = chartType,
                showSma = showSma,
                showEma = showEma
            )
        }

        // ACTIVE TRADES CHIP STRIP
        if (activeTrades.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkNavySurface)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                activeTrades.forEach { trade ->
                    val isCall = trade.direction == TradeDirection.CALL
                    val color = if (isCall) TradeBullGreen else TradeBearRed
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(color.copy(alpha = 0.15f))
                            .border(1.dp, color, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isCall) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                contentDescription = null,
                                tint = color,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${trade.assetSymbol} $${trade.investmentAmount.toInt()} • ${trade.remainingSeconds}s",
                                color = color,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // TRADING EXECUTION BOTTOM DOCK
        TradingExecutionPanel(
            selectedAsset = selectedAsset,
            investmentAmount = investmentAmount,
            selectedTimeframe = selectedTimeframe,
            onSetInvestment = { viewModel.setInvestmentAmount(it) },
            onCall = { viewModel.placeTrade(TradeDirection.CALL) },
            onPut = { viewModel.placeTrade(TradeDirection.PUT) }
        )
    }
}

@Composable
private fun TradingExecutionPanel(
    selectedAsset: Asset,
    investmentAmount: Double,
    selectedTimeframe: TimeFrame,
    onSetInvestment: (Double) -> Unit,
    onCall: () -> Unit,
    onPut: () -> Unit
) {
    val potentialProfit = investmentAmount * selectedAsset.payoutRate

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkNavySurface)
            .border(1.dp, DarkNavyOutline, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .padding(12.dp)
    ) {
        // Investment Amount Controller
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "INVESTMENT",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "$${investmentAmount.toInt()}",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Quick increment chips
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(10.0, 50.0, 100.0, 500.0).forEach { inc ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkNavySurfaceVariant)
                            .clickable { onSetInvestment(inc) }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "+$${inc.toInt()}",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "PROFIT (${(selectedAsset.payoutRate * 100).toInt()}%)",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "+$${"%,.2f".format(potentialProfit)}",
                    color = TradeBullGreen,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Big CALL / PUT Execution Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // CALL BUTTON
            Button(
                onClick = onCall,
                colors = ButtonDefaults.buttonColors(containerColor = TradeBullGreen),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("trade_call_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowUpward,
                        contentDescription = "CALL (Higher)",
                        tint = Color.Black,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "CALL (HIGHER)",
                            color = Color.Black,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "+$${"%.0f".format(potentialProfit)} in ${selectedTimeframe.label}",
                            color = Color.Black.copy(alpha = 0.8f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // PUT BUTTON
            Button(
                onClick = onPut,
                colors = ButtonDefaults.buttonColors(containerColor = TradeBearRed),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("trade_put_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = "PUT (Lower)",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "PUT (LOWER)",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "+$${"%.0f".format(potentialProfit)} in ${selectedTimeframe.label}",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
