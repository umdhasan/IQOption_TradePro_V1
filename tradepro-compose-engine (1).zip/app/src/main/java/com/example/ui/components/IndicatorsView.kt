package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.DarkNavySurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TradeBearRed
import com.example.ui.theme.TradeBullGreen

@Composable
fun IndicatorsView(
    showSma: Boolean,
    onToggleSma: () -> Unit,
    showEma: Boolean,
    onToggleEma: () -> Unit,
    rsiValue: Double?,
    macdValue: Double?,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkNavySurface)
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // SMA toggle chip
        IndicatorChip(
            label = "SMA (9)",
            active = showSma,
            activeColor = AccentGold,
            onClick = onToggleSma
        )

        // EMA toggle chip
        IndicatorChip(
            label = "EMA (21)",
            active = showEma,
            activeColor = AccentCyan,
            onClick = onToggleEma
        )

        // RSI live indicator
        rsiValue?.let { rsi ->
            val rsiColor = when {
                rsi <= 30.0 -> TradeBullGreen
                rsi >= 70.0 -> TradeBearRed
                else -> AccentCyan
            }
            val status = when {
                rsi <= 30.0 -> "Oversold"
                rsi >= 70.0 -> "Overbought"
                else -> "Neutral"
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(DarkNavySurfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "RSI: ${"%.1f".format(rsi)} ($status)",
                    color = rsiColor,
                    fontSize = 11.sp
                )
            }
        }

        // MACD live indicator
        macdValue?.let { macd ->
            val macdColor = if (macd >= 0) TradeBullGreen else TradeBearRed
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(DarkNavySurfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "MACD: ${if (macd >= 0) "+" else ""}${"%.4f".format(macd)}",
                    color = macdColor,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun IndicatorChip(
    label: String,
    active: Boolean,
    activeColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (active) activeColor.copy(alpha = 0.2f) else DarkNavySurfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            color = if (active) activeColor else TextMuted,
            fontSize = 11.sp
        )
    }
}
