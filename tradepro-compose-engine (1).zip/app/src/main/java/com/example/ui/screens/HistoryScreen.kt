package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Trade
import com.example.model.TradeDirection
import com.example.model.TradeStatus
import com.example.ui.TradeProViewModel
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.DarkNavyBackground
import com.example.ui.theme.DarkNavyOutline
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.DarkNavySurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TradeBearRed
import com.example.ui.theme.TradeBullGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    viewModel: TradeProViewModel,
    modifier: Modifier = Modifier
) {
    val tradeHistory by viewModel.tradeHistory.collectAsState()

    val totalTrades = tradeHistory.size
    val wins = tradeHistory.count { it.status == TradeStatus.WON }
    val winRate = if (totalTrades > 0) (wins * 100) / totalTrades else 0
    val netPnl = tradeHistory.sumOf { it.profitLoss }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBackground)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkNavySurface)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.History,
                    contentDescription = null,
                    tint = AccentCyan,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Trade History",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (tradeHistory.isNotEmpty()) {
                IconButton(onClick = { viewModel.clearTradeHistory() }) {
                    Icon(
                        imageVector = Icons.Default.Restore,
                        contentDescription = "Clear History",
                        tint = TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Summary Stats Cards
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatCard(
                title = "Total Trades",
                value = "$totalTrades",
                valueColor = TextPrimary,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Win Rate",
                value = "$winRate%",
                valueColor = if (winRate >= 50) TradeBullGreen else TradeBearRed,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Net P&L",
                value = "${if (netPnl >= 0) "+" else ""}$${"%,.2f".format(netPnl)}",
                valueColor = if (netPnl >= 0) TradeBullGreen else TradeBearRed,
                modifier = Modifier.weight(1f)
            )
        }

        // Trade History List
        if (tradeHistory.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No trades placed yet. Use the Terminal to open trades.",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tradeHistory, key = { it.id }) { trade ->
                    TradeHistoryItem(trade = trade)
                }
            }
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    valueColor: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(DarkNavySurface)
            .border(1.dp, DarkNavyOutline, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(
                text = title,
                color = TextMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                color = valueColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun TradeHistoryItem(trade: Trade) {
    val isCall = trade.direction == TradeDirection.CALL
    val dirColor = if (isCall) TradeBullGreen else TradeBearRed
    val statusColor = when (trade.status) {
        TradeStatus.WON -> TradeBullGreen
        TradeStatus.LOST -> TradeBearRed
        TradeStatus.TIE -> AccentGold
        TradeStatus.OPEN -> AccentCyan
    }

    val timeFormatted = remember(trade.createdAt) {
        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(trade.createdAt))
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(DarkNavySurface)
            .border(1.dp, DarkNavyOutline, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isCall) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                        contentDescription = null,
                        tint = dirColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${trade.assetSymbol} (${trade.productType.displayName})",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                val entryStr = if (trade.entryPrice >= 100) "%.2f".format(trade.entryPrice) else "%.5f".format(trade.entryPrice)
                val exitStr = trade.exitPrice?.let { if (it >= 100) "%.2f".format(it) else "%.5f".format(it) } ?: "-"
                Text(
                    text = "Entry: $entryStr  Exit: $exitStr",
                    color = TextMuted,
                    fontSize = 11.sp
                )
                Text(
                    text = "Time: $timeFormatted • ${trade.durationSeconds}s expiry",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                // Status badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = trade.status.name,
                        color = statusColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                val pnlFormatted = "${if (trade.profitLoss >= 0) "+" else ""}$${"%.2f".format(trade.profitLoss)}"
                Text(
                    text = pnlFormatted,
                    color = statusColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
