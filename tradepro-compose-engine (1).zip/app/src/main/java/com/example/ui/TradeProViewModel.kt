package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.AlertDao
import com.example.database.AlertEntity
import com.example.database.SignalDao
import com.example.database.SignalEntity
import com.example.database.TradeDao
import com.example.database.TradeEntity
import com.example.database.TradeProDatabase
import com.example.engine.AlertEngine
import com.example.engine.AlertSoundManager
import com.example.engine.MarketEngine
import com.example.engine.MarketSessionEngine
import com.example.engine.SignalEngine
import com.example.engine.TechnicalAnalysisEngine
import com.example.engine.TradeSettlementEngine
import com.example.model.Alert
import com.example.model.AlertCondition
import com.example.model.Asset
import com.example.model.Candle
import com.example.model.ProductType
import com.example.model.Signal
import com.example.model.TimeFrame
import com.example.model.Trade
import com.example.model.TradeDirection
import com.example.model.TradeStatus
import com.example.provider.MarketDataProvider
import com.example.provider.RealMarketDataProvider
import com.example.ui.components.ChartType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

class TradeProViewModel(
    application: Application
) : AndroidViewModel(application) {

    private var dataProvider: MarketDataProvider = RealMarketDataProvider(viewModelScope)

    constructor(application: Application, customProvider: MarketDataProvider) : this(application) {
        this.dataProvider = customProvider
    }

    private val db = TradeProDatabase.getDatabase(application)
    private val tradeDao: TradeDao = db.tradeDao()
    private val alertDao: AlertDao = db.alertDao()
    private val signalDao: SignalDao = db.signalDao()
    private val soundManager = AlertSoundManager(application)

    // Demo balance
    private val _demoBalance = MutableStateFlow(10000.0)
    val demoBalance: StateFlow<Double> = _demoBalance.asStateFlow()

    // Market status badge: Live when connected, or Simulated/Demo
    val statusLabel: String
        get() = dataProvider.statusLabel

    val isLiveFeed: Boolean
        get() = dataProvider.isLiveFeed

    // Active product tab
    private val _activeProductType = MutableStateFlow(ProductType.DIGITAL)
    val activeProductType: StateFlow<ProductType> = _activeProductType.asStateFlow()

    // Available assets for current product
    private val _assets = MutableStateFlow<List<Asset>>(emptyList())
    val assets: StateFlow<List<Asset>> = _assets.asStateFlow()

    // Selected asset
    private val _selectedAsset = MutableStateFlow(
        MarketEngine.getDefaultAssets(ProductType.DIGITAL).first()
    )
    val selectedAsset: StateFlow<Asset> = _selectedAsset.asStateFlow()

    // Selected timeframe
    private val _selectedTimeframe = MutableStateFlow(TimeFrame("1m", 60))
    val selectedTimeframe: StateFlow<TimeFrame> = _selectedTimeframe.asStateFlow()

    // Investment amount
    private val _investmentAmount = MutableStateFlow(100.0)
    val investmentAmount: StateFlow<Double> = _investmentAmount.asStateFlow()

    // Live price of current asset
    private val _currentPrice = MutableStateFlow(1.08450)
    val currentPrice: StateFlow<Double> = _currentPrice.asStateFlow()

    // Candles for chart
    private val _candles = MutableStateFlow<List<Candle>>(emptyList())
    val candles: StateFlow<List<Candle>> = _candles.asStateFlow()

    // Active trades in progress
    private val _activeTrades = MutableStateFlow<List<Trade>>(emptyList())
    val activeTrades: StateFlow<List<Trade>> = _activeTrades.asStateFlow()

    // Trade history (closed trades)
    private val _tradeHistory = MutableStateFlow<List<Trade>>(emptyList())
    val tradeHistory: StateFlow<List<Trade>> = _tradeHistory.asStateFlow()

    // Signals
    private val _signals = MutableStateFlow<List<Signal>>(emptyList())
    val signals: StateFlow<List<Signal>> = _signals.asStateFlow()

    // Alerts
    private val _alerts = MutableStateFlow<List<Alert>>(emptyList())
    val alerts: StateFlow<List<Alert>> = _alerts.asStateFlow()

    // Indicator toggles
    private val _showSma = MutableStateFlow(true)
    val showSma: StateFlow<Boolean> = _showSma.asStateFlow()

    private val _showEma = MutableStateFlow(true)
    val showEma: StateFlow<Boolean> = _showEma.asStateFlow()

    private val _chartType = MutableStateFlow(ChartType.CANDLESTICK)
    val chartType: StateFlow<ChartType> = _chartType.asStateFlow()

    // Technical readings
    private val _rsiValue = MutableStateFlow<Double?>(null)
    val rsiValue: StateFlow<Double?> = _rsiValue.asStateFlow()

    private val _macdValue = MutableStateFlow<Double?>(null)
    val macdValue: StateFlow<Double?> = _macdValue.asStateFlow()

    // Active session summary
    val sessionSummary: String = MarketSessionEngine.getActiveSessionSummary()

    init {
        loadProductAssets(ProductType.DIGITAL)
        observeDatabase()
        startLiveMarketTickObserver()
        startTradeSettlementLoop()
        startSignalScanningLoop()
    }

    private fun observeDatabase() {
        viewModelScope.launch(Dispatchers.IO) {
            tradeDao.getAllTradesFlow().collect { entities ->
                val list = entities.map { it.toDomain() }
                _tradeHistory.value = list.filter { it.status != TradeStatus.OPEN }
                val open = list.filter { it.status == TradeStatus.OPEN }
                _activeTrades.value = open
            }
        }

        viewModelScope.launch(Dispatchers.IO) {
            alertDao.getAllAlertsFlow().collect { entities ->
                _alerts.value = entities.map { it.toDomain() }
            }
        }

        viewModelScope.launch(Dispatchers.IO) {
            signalDao.getAllSignalsFlow().collect { entities ->
                _signals.value = entities.map { it.toDomain() }
            }
        }
    }

    fun setProductType(type: ProductType) {
        _activeProductType.value = type
        loadProductAssets(type)

        // Blitz defaults to 5s timeframe
        if (type == ProductType.BLITZ) {
            _selectedTimeframe.value = TimeFrame("5s", 5)
        } else if (_selectedTimeframe.value.seconds < type.minDurationSeconds && type != ProductType.BLITZ) {
            _selectedTimeframe.value = TimeFrame.ALL.firstOrNull { it.seconds >= type.minDurationSeconds }
                ?: TimeFrame("1m", 60)
        }
    }

    private fun loadProductAssets(type: ProductType) {
        val list = MarketEngine.getDefaultAssets(type)
        list.forEach { dataProvider.registerAsset(it.symbol, it.currentPrice) }
        _assets.value = list
        val currentSymbol = _selectedAsset.value.symbol
        val matched = list.firstOrNull { it.symbol == currentSymbol } ?: list.first()
        selectAsset(matched)
    }

    fun selectAsset(asset: Asset) {
        _selectedAsset.value = asset
        _currentPrice.value = dataProvider.getCurrentPrice(asset.symbol)
        refreshCandles(asset.symbol)
    }

    fun selectTimeframe(timeframe: TimeFrame) {
        _selectedTimeframe.value = timeframe
        refreshCandles(_selectedAsset.value.symbol)
    }

    fun setInvestmentAmount(amount: Double) {
        _investmentAmount.value = amount.coerceAtLeast(1.0)
    }

    fun toggleSma() {
        _showSma.value = !_showSma.value
    }

    fun toggleEma() {
        _showEma.value = !_showEma.value
    }

    fun toggleChartType() {
        _chartType.value = if (_chartType.value == ChartType.CANDLESTICK) ChartType.AREA else ChartType.CANDLESTICK
    }

    fun resetDemoBalance(newAmount: Double) {
        _demoBalance.value = newAmount
    }

    fun placeTrade(direction: TradeDirection): Boolean {
        val amount = _investmentAmount.value
        if (_demoBalance.value < amount) return false

        // Deduct investment from demo balance immediately
        _demoBalance.value -= amount

        val asset = _selectedAsset.value
        val entryPrice = _currentPrice.value
        val duration = _selectedTimeframe.value.seconds

        val newTrade = Trade(
            id = UUID.randomUUID().toString(),
            assetSymbol = asset.symbol,
            productType = _activeProductType.value,
            direction = direction,
            investmentAmount = amount,
            entryPrice = entryPrice,
            payoutRate = asset.payoutRate,
            durationSeconds = duration
        )

        _activeTrades.update { listOf(newTrade) + it }

        viewModelScope.launch(Dispatchers.IO) {
            tradeDao.insertTrade(TradeEntity.fromDomain(newTrade))
        }

        return true
    }

    private fun startLiveMarketTickObserver() {
        viewModelScope.launch {
            while (isActive) {
                delay(300L)
                val symbol = _selectedAsset.value.symbol
                val newPrice = dataProvider.getCurrentPrice(symbol)
                _currentPrice.value = newPrice

                // Refresh candles and indicators
                val updatedCandles = dataProvider.getCandles(symbol, _selectedTimeframe.value.seconds)
                _candles.value = updatedCandles

                if (updatedCandles.isNotEmpty()) {
                    _rsiValue.value = TechnicalAnalysisEngine.calculateRSI(updatedCandles)
                    _macdValue.value = TechnicalAnalysisEngine.calculateMACD(updatedCandles)?.histogram
                }

                // Check price alerts
                checkPriceAlerts(symbol, newPrice)
            }
        }
    }

    private fun checkPriceAlerts(symbol: String, price: Double) {
        val triggered = AlertEngine.checkAlerts(_alerts.value, symbol, price)
        if (triggered.isNotEmpty()) {
            soundManager.playAlertTriggered()
            viewModelScope.launch(Dispatchers.IO) {
                triggered.forEach { alertDao.updateAlert(AlertEntity.fromDomain(it)) }
            }
        }
    }

    private fun startTradeSettlementLoop() {
        viewModelScope.launch {
            while (isActive) {
                delay(200L)
                val currentTrades = _activeTrades.value
                val now = System.currentTimeMillis()

                val toSettle = currentTrades.filter { it.expiresAt <= now }
                if (toSettle.isNotEmpty()) {
                    val remaining = currentTrades.filter { it.expiresAt > now }
                    _activeTrades.value = remaining

                    toSettle.forEach { trade ->
                        val exitPrice = dataProvider.getCurrentPrice(trade.assetSymbol)
                        val settledTrade = TradeSettlementEngine.settleTrade(trade, exitPrice)

                        // Calculate settlement returns
                        val result = TradeSettlementEngine.settleTrade(
                            direction = trade.direction,
                            entryPrice = trade.entryPrice,
                            exitPrice = exitPrice,
                            investmentAmount = trade.investmentAmount,
                            payoutRate = trade.payoutRate
                        )

                        // If WON or TIE, refund/payout to balance
                        _demoBalance.value += result.totalPayout

                        if (result.status == TradeStatus.WON) {
                            soundManager.playTradeWon()
                        } else if (result.status == TradeStatus.LOST) {
                            soundManager.playTradeLost()
                        }

                        // Persist settled trade in Room
                        viewModelScope.launch(Dispatchers.IO) {
                            tradeDao.updateTrade(TradeEntity.fromDomain(settledTrade))
                        }
                    }
                }
            }
        }
    }

    private fun startSignalScanningLoop() {
        viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(12000L) // Scan for signals every 12s
                val currentAssets = _assets.value
                val newSignals = mutableListOf<Signal>()

                currentAssets.forEach { asset ->
                    val candles = dataProvider.getCandles(asset.symbol, 60, 40)
                    val signal = SignalEngine.generateSignal(asset, candles, "1m")
                    if (signal != null) {
                        newSignals.add(signal)
                    }
                }

                if (newSignals.isNotEmpty()) {
                    viewModelScope.launch(Dispatchers.IO) {
                        signalDao.insertSignals(newSignals.map { SignalEntity.fromDomain(it) })
                    }
                }
            }
        }
    }

    fun createAlert(targetPrice: Double, condition: AlertCondition) {
        val newAlert = Alert(
            id = UUID.randomUUID().toString(),
            assetSymbol = _selectedAsset.value.symbol,
            targetPrice = targetPrice,
            condition = condition
        )
        viewModelScope.launch(Dispatchers.IO) {
            alertDao.insertAlert(AlertEntity.fromDomain(newAlert))
        }
    }

    fun deleteAlert(alertId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            alertDao.deleteAlertById(alertId)
        }
    }

    fun applySignalAndTrade(signal: Signal) {
        val targetAsset = _assets.value.firstOrNull { it.symbol == signal.assetSymbol }
            ?: Asset(signal.assetSymbol, signal.assetSymbol, signal.productType, dataProvider.getCurrentPrice(signal.assetSymbol), 0.0, 0.0, 0.0)

        selectAsset(targetAsset)
        placeTrade(signal.direction)
    }

    fun clearTradeHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            tradeDao.clearAllTrades()
        }
    }

    private fun refreshCandles(symbol: String) {
        _candles.value = dataProvider.getCandles(symbol, _selectedTimeframe.value.seconds)
    }

    override fun onCleared() {
        super.onCleared()
        soundManager.release()
    }
}
