package com.example.model

enum class AlertCondition {
    ABOVE, BELOW
}

data class Alert(
    val id: String,
    val assetSymbol: String,
    val targetPrice: Double,
    val condition: AlertCondition,
    val isTriggered: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
