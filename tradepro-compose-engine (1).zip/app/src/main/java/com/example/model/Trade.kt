package com.example.model

enum class TradeDirection {
    CALL, PUT
}

enum class TradeStatus {
    OPEN, WON, LOST, TIE
}

data class Trade(
    val id: String,
    val assetSymbol: String,
    val productType: ProductType,
    val direction: TradeDirection,
    val investmentAmount: Double,
    val entryPrice: Double,
    val exitPrice: Double? = null,
    val payoutRate: Double,
    val status: TradeStatus = TradeStatus.OPEN,
    val profitLoss: Double = 0.0,
    val durationSeconds: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = createdAt + (durationSeconds * 1000L)
) {
    val remainingSeconds: Int
        get() {
            val diff = (expiresAt - System.currentTimeMillis()) / 1000L
            return if (diff > 0) diff.toInt() else 0
        }

    val isExpired: Boolean
        get() = System.currentTimeMillis() >= expiresAt
}
