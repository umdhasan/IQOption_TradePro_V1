package com.example.model

data class Signal(
    val id: String,
    val assetSymbol: String,
    val productType: ProductType,
    val direction: TradeDirection,
    val confidence: Int, // e.g. 87%
    val timeframe: String, // e.g. "1m", "5s"
    val reason: String, // e.g. "RSI Oversold (24.2) + MACD Bullish Cross"
    val timestamp: Long = System.currentTimeMillis()
)
