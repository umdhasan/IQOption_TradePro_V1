package com.example.model

enum class ProductType(val displayName: String, val defaultPayoutRate: Double, val minDurationSeconds: Int) {
    DIGITAL("Digital", 0.92, 60),
    BINARY("Binary", 0.88, 30),
    FOREX("Forex", 0.82, 120),
    BLITZ("Blitz", 0.95, 5)
}

data class TimeFrame(
    val label: String,
    val seconds: Int
) {
    companion object {
        val ALL = listOf(
            TimeFrame("5s", 5),
            TimeFrame("15s", 15),
            TimeFrame("30s", 30),
            TimeFrame("1m", 60),
            TimeFrame("2m", 120),
            TimeFrame("5m", 300)
        )
    }
}

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 1.0
)

data class PriceTick(
    val timestamp: Long,
    val price: Double,
    val volume: Double = 1.0
)

data class Asset(
    val symbol: String,
    val name: String,
    val productType: ProductType,
    val currentPrice: Double,
    val change24h: Double,
    val high24h: Double,
    val low24h: Double,
    val payoutRate: Double = productType.defaultPayoutRate,
    val category: String = "Currencies"
) {
    val isBullish: Boolean get() = change24h >= 0
}
