package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.ProductType
import com.example.model.Trade
import com.example.model.TradeDirection
import com.example.model.TradeStatus

@Entity(tableName = "trades")
data class TradeEntity(
    @PrimaryKey val id: String,
    val assetSymbol: String,
    val productType: String,
    val direction: String,
    val investmentAmount: Double,
    val entryPrice: Double,
    val exitPrice: Double?,
    val payoutRate: Double,
    val status: String,
    val profitLoss: Double,
    val durationSeconds: Int,
    val createdAt: Long,
    val expiresAt: Long
) {
    fun toDomain(): Trade {
        return Trade(
            id = id,
            assetSymbol = assetSymbol,
            productType = runCatching { ProductType.valueOf(productType) }.getOrDefault(ProductType.BINARY),
            direction = runCatching { TradeDirection.valueOf(direction) }.getOrDefault(TradeDirection.CALL),
            investmentAmount = investmentAmount,
            entryPrice = entryPrice,
            exitPrice = exitPrice,
            payoutRate = payoutRate,
            status = runCatching { TradeStatus.valueOf(status) }.getOrDefault(TradeStatus.OPEN),
            profitLoss = profitLoss,
            durationSeconds = durationSeconds,
            createdAt = createdAt,
            expiresAt = expiresAt
        )
    }

    companion object {
        fun fromDomain(trade: Trade): TradeEntity {
            return TradeEntity(
                id = trade.id,
                assetSymbol = trade.assetSymbol,
                productType = trade.productType.name,
                direction = trade.direction.name,
                investmentAmount = trade.investmentAmount,
                entryPrice = trade.entryPrice,
                exitPrice = trade.exitPrice,
                payoutRate = trade.payoutRate,
                status = trade.status.name,
                profitLoss = trade.profitLoss,
                durationSeconds = trade.durationSeconds,
                createdAt = trade.createdAt,
                expiresAt = trade.expiresAt
            )
        }
    }
}
