package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.Alert
import com.example.model.AlertCondition

@Entity(tableName = "alerts")
data class AlertEntity(
    @PrimaryKey val id: String,
    val assetSymbol: String,
    val targetPrice: Double,
    val condition: String,
    val isTriggered: Boolean,
    val createdAt: Long
) {
    fun toDomain(): Alert {
        return Alert(
            id = id,
            assetSymbol = assetSymbol,
            targetPrice = targetPrice,
            condition = runCatching { AlertCondition.valueOf(condition) }.getOrDefault(AlertCondition.ABOVE),
            isTriggered = isTriggered,
            createdAt = createdAt
        )
    }

    companion object {
        fun fromDomain(alert: Alert): AlertEntity {
            return AlertEntity(
                id = alert.id,
                assetSymbol = alert.assetSymbol,
                targetPrice = alert.targetPrice,
                condition = alert.condition.name,
                isTriggered = alert.isTriggered,
                createdAt = alert.createdAt
            )
        }
    }
}
