package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.ProductType
import com.example.model.Signal
import com.example.model.TradeDirection

@Entity(tableName = "signals")
data class SignalEntity(
    @PrimaryKey val id: String,
    val assetSymbol: String,
    val productType: String,
    val direction: String,
    val confidence: Int,
    val timeframe: String,
    val reason: String,
    val timestamp: Long
) {
    fun toDomain(): Signal {
        return Signal(
            id = id,
            assetSymbol = assetSymbol,
            productType = runCatching { ProductType.valueOf(productType) }.getOrDefault(ProductType.DIGITAL),
            direction = runCatching { TradeDirection.valueOf(direction) }.getOrDefault(TradeDirection.CALL),
            confidence = confidence,
            timeframe = timeframe,
            reason = reason,
            timestamp = timestamp
        )
    }

    companion object {
        fun fromDomain(signal: Signal): SignalEntity {
            return SignalEntity(
                id = signal.id,
                assetSymbol = signal.assetSymbol,
                productType = signal.productType.name,
                direction = signal.direction.name,
                confidence = signal.confidence,
                timeframe = signal.timeframe,
                reason = signal.reason,
                timestamp = signal.timestamp
            )
        }
    }
}
