package com.example.provider

import com.example.model.Candle
import com.example.model.PriceTick
import kotlinx.coroutines.flow.Flow

interface MarketDataProvider {
    val isLiveFeed: Boolean
    val statusLabel: String

    fun getCurrentPrice(symbol: String): Double
    fun getTicksFlow(symbol: String): Flow<PriceTick>
    fun getCandles(symbol: String, timeframeSeconds: Int, count: Int = 60): List<Candle>
    fun registerAsset(symbol: String, initialPrice: Double)
}
