package com.example.provider

import com.example.model.Candle
import com.example.model.PriceTick
import kotlinx.coroutines.flow.Flow

/**
 * RemoteProxyMarketDataProvider routes market data through an external gateway.
 * Per project policy: Without authenticated broker credentials,
 * it strictly enforces the "SIMULATED / DEMO DATA" status label.
 */
class RemoteProxyMarketDataProvider(
    private val fallbackProvider: SimulatedMarketDataProvider = SimulatedMarketDataProvider(),
    private val apiKey: String? = null
) : MarketDataProvider {

    // Strictly false unless authorized live broker key is provided
    override val isLiveFeed: Boolean
        get() = !apiKey.isNullOrBlank() && apiKey != "DEMO_KEY"

    override val statusLabel: String
        get() = if (isLiveFeed) "LIVE FEED (AUTHENTICATED)" else "SIMULATED / DEMO DATA"

    override fun getCurrentPrice(symbol: String): Double {
        return fallbackProvider.getCurrentPrice(symbol)
    }

    override fun getTicksFlow(symbol: String): Flow<PriceTick> {
        return fallbackProvider.getTicksFlow(symbol)
    }

    override fun getCandles(symbol: String, timeframeSeconds: Int, count: Int): List<Candle> {
        return fallbackProvider.getCandles(symbol, timeframeSeconds, count)
    }

    override fun registerAsset(symbol: String, initialPrice: Double) {
        fallbackProvider.registerAsset(symbol, initialPrice)
    }
}
