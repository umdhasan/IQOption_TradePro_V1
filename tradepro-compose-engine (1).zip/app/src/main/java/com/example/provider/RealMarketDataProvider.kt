package com.example.provider

import com.example.model.Candle
import com.example.model.PriceTick
import com.example.network.FinancialMarketRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import kotlin.random.Random

/**
 * RealMarketDataProvider connects the simulated trading terminal to real-world live market feeds
 * using Retrofit services (Finnhub API for stocks, OpenForex for currency pairs, and Binance for crypto).
 */
class RealMarketDataProvider(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default),
    private val repository: FinancialMarketRepository = FinancialMarketRepository()
) : MarketDataProvider {

    @Volatile
    private var hasSuccessfulLiveFetch: Boolean = false

    override val isLiveFeed: Boolean
        get() = hasSuccessfulLiveFetch

    override val statusLabel: String
        get() = if (hasSuccessfulLiveFetch) {
            if (repository.isFinnhubConfigured) "LIVE RETROFIT FEED (FINNHUB + FOREX)"
            else "LIVE MARKET FEED (DEMO ACCOUNT)"
        } else {
            "SIMULATED / DEMO DATA"
        }

    private val assetPrices = ConcurrentHashMap<String, Double>()
    private val tickFlows = ConcurrentHashMap<String, MutableSharedFlow<PriceTick>>()
    private val candleCaches = ConcurrentHashMap<String, MutableList<Candle>>()

    init {
        // Initialize default baseline prices
        initDefaults()

        // Loop 1: High frequency live micro-tick generator around the real live anchor
        scope.launch {
            while (isActive) {
                delay(400L) // smooth 2-3 ticks per second
                val now = System.currentTimeMillis()

                assetPrices.forEach { (symbol, currentPrice) ->
                    val volatility = getVolatility(symbol, currentPrice)
                    val delta = (Random.nextDouble() - 0.499) * volatility
                    val newPrice = (currentPrice + delta).coerceAtLeast(0.00001)

                    assetPrices[symbol] = newPrice
                    val tick = PriceTick(now, newPrice, Random.nextDouble(0.5, 4.0))

                    tickFlows[symbol]?.tryEmit(tick)
                    updateCandleCache(symbol, newPrice, now)
                }
            }
        }

        // Loop 2: Real live market price fetcher via Retrofit (Forex, Crypto, Finnhub Stocks)
        scope.launch {
            while (isActive) {
                fetchRealMarketPrices()
                delay(3000L) // refresh live quotes every 3s
            }
        }

        // Loop 3: Fetch real klines via Retrofit for Crypto
        scope.launch {
            delay(1000L)
            fetchRealCryptoKlines("BTC/USD")
            fetchRealCryptoKlines("ETH/USD")
            fetchRealCryptoKlines("SOL/USD")
        }
    }

    private fun initDefaults() {
        val defaults = mapOf(
            "EUR/USD" to 1.08450,
            "GBP/USD" to 1.29820,
            "USD/JPY" to 153.250,
            "BTC/USD" to 82000.0,
            "ETH/USD" to 2460.0,
            "SOL/USD" to 106.0,
            "XAU/USD" to 2735.0,
            "AUD/USD" to 0.66250,
            "USD/CAD" to 1.38500,
            "USD/CHF" to 0.86650,
            "GBP/JPY" to 198.900,
            "NZD/USD" to 0.59950,
            "EUR/GBP" to 0.83540,
            "USD/MXN" to 19.850,
            "AAPL/USD" to 235.50,
            "TSLA/USD" to 220.80,
            "NVDA/USD" to 138.20
        )
        defaults.forEach { (symbol, price) ->
            registerAsset(symbol, price)
        }
    }

    override fun registerAsset(symbol: String, initialPrice: Double) {
        if (!assetPrices.containsKey(symbol)) {
            assetPrices[symbol] = initialPrice
            tickFlows[symbol] = MutableSharedFlow(replay = 1, extraBufferCapacity = 16)
            generateInitialCandles(symbol, initialPrice)
        }
    }

    override fun getCurrentPrice(symbol: String): Double {
        return assetPrices[symbol] ?: 1.08450
    }

    override fun getTicksFlow(symbol: String): Flow<PriceTick> {
        return tickFlows.getOrPut(symbol) {
            MutableSharedFlow(replay = 1, extraBufferCapacity = 16)
        }.asSharedFlow()
    }

    override fun getCandles(symbol: String, timeframeSeconds: Int, count: Int): List<Candle> {
        val cached = candleCaches[symbol] ?: emptyList()
        if (cached.isEmpty()) {
            val initial = getCurrentPrice(symbol)
            generateInitialCandles(symbol, initial)
            return candleCaches[symbol]?.takeLast(count) ?: emptyList()
        }
        return cached.takeLast(count)
    }

    private suspend fun fetchRealMarketPrices() {
        var anySuccess = false

        // 1. Fetch real live forex rates via Retrofit
        runCatching {
            val forexRates = repository.fetchForexRates()
            if (forexRates.isNotEmpty()) {
                forexRates.forEach { (symbol, price) ->
                    assetPrices[symbol] = price
                }
                anySuccess = true
            }
        }

        // 2. Fetch real live crypto prices via Retrofit
        runCatching {
            val cryptoPrices = repository.fetchCryptoPrices()
            if (cryptoPrices.isNotEmpty()) {
                cryptoPrices.forEach { (symbol, price) ->
                    assetPrices[symbol] = price
                }
                anySuccess = true
            }
        }

        // 3. Fetch real live stock quotes via Finnhub Retrofit API (if configured)
        if (repository.isFinnhubConfigured) {
            listOf("AAPL", "TSLA", "NVDA").forEach { ticker ->
                runCatching {
                    val quote = repository.fetchStockQuote(ticker)
                    val price = quote?.currentPrice
                    if (price != null && price > 0) {
                        assetPrices["$ticker/USD"] = price
                        anySuccess = true
                    }
                }
            }
        }

        if (anySuccess) {
            hasSuccessfulLiveFetch = true
        }
    }

    private suspend fun fetchRealCryptoKlines(pairSymbol: String) {
        runCatching {
            val klines = repository.fetchCryptoKlines(pairSymbol, 60)
            if (klines.isNotEmpty()) {
                candleCaches[pairSymbol] = klines.toMutableList()
                assetPrices[pairSymbol] = klines.last().close
            }
        }
    }

    private fun getVolatility(symbol: String, price: Double): Double {
        return when {
            symbol.startsWith("BTC") -> price * 0.00015
            symbol.startsWith("ETH") -> price * 0.0002
            symbol.startsWith("SOL") -> price * 0.0003
            symbol.startsWith("XAU") -> 0.15
            symbol.contains("JPY") -> 0.015
            symbol.contains("AAPL") || symbol.contains("TSLA") || symbol.contains("NVDA") -> 0.08
            else -> 0.00005
        }
    }

    private fun generateInitialCandles(symbol: String, basePrice: Double) {
        val list = mutableListOf<Candle>()
        var current = basePrice
        val now = System.currentTimeMillis()
        val intervalMs = 5000L

        val count = 60
        val startTime = now - (count * intervalMs)

        for (i in 0 until count) {
            val candleTime = startTime + (i * intervalMs)
            val vol = getVolatility(symbol, current) * 1.5
            val open = current
            val change1 = (Random.nextDouble() - 0.495) * vol
            val close = (open + change1).coerceAtLeast(0.00001)
            val high = maxOf(open, close) + Random.nextDouble() * vol * 0.4
            val low = minOf(open, close) - Random.nextDouble() * vol * 0.4

            list.add(Candle(candleTime, open, high, low, close, Random.nextDouble(5.0, 30.0)))
            current = close
        }
        candleCaches[symbol] = list
        assetPrices[symbol] = current
    }

    private fun updateCandleCache(symbol: String, newPrice: Double, timestamp: Long) {
        val list = candleCaches[symbol] ?: return
        if (list.isEmpty()) return

        val lastCandle = list.last()
        val candleDurationMs = 5000L

        if (timestamp - lastCandle.timestamp < candleDurationMs) {
            val updated = lastCandle.copy(
                high = maxOf(lastCandle.high, newPrice),
                low = minOf(lastCandle.low, newPrice),
                close = newPrice,
                volume = lastCandle.volume + 1.0
            )
            list[list.lastIndex] = updated
        } else {
            val newCandle = Candle(
                timestamp = timestamp,
                open = lastCandle.close,
                high = maxOf(lastCandle.close, newPrice),
                low = minOf(lastCandle.close, newPrice),
                close = newPrice,
                volume = 1.0
            )
            list.add(newCandle)
            if (list.size > 150) {
                list.removeAt(0)
            }
        }
    }
}
