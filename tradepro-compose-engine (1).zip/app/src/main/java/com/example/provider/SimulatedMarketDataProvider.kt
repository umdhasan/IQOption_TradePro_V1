package com.example.provider

import com.example.model.Candle
import com.example.model.PriceTick
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import kotlin.random.Random

class SimulatedMarketDataProvider(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) : MarketDataProvider {

    override val isLiveFeed: Boolean = false
    override val statusLabel: String = "SIMULATED / DEMO DATA"

    private val assetPrices = ConcurrentHashMap<String, Double>()
    private val tickFlows = ConcurrentHashMap<String, MutableSharedFlow<PriceTick>>()
    private val candleCaches = ConcurrentHashMap<String, MutableList<Candle>>()

    init {
        // Background ticker loop generating continuous ticks
        scope.launch {
            while (isActive) {
                delay(300L) // high frequency ticks (~3 ticks per sec)
                val now = System.currentTimeMillis()

                assetPrices.forEach { (symbol, currentPrice) ->
                    val volatility = getVolatilityForSymbol(symbol, currentPrice)
                    val delta = (Random.nextDouble() - 0.498) * volatility
                    val newPrice = (currentPrice + delta).coerceAtLeast(0.00001)

                    assetPrices[symbol] = newPrice
                    val tick = PriceTick(now, newPrice, Random.nextDouble(0.5, 5.0))

                    tickFlows[symbol]?.tryEmit(tick)
                    updateCandleCache(symbol, newPrice, now)
                }
            }
        }
    }

    override fun registerAsset(symbol: String, initialPrice: Double) {
        if (!assetPrices.containsKey(symbol)) {
            assetPrices[symbol] = initialPrice
            tickFlows[symbol] = MutableSharedFlow(replay = 1, extraBufferCapacity = 16)
            generateInitialCandles(symbol, initialPrice)
        }
    }

    override fun getCurrentPrice(symbol: String): Double {
        return assetPrices[symbol] ?: 1.08450
    }

    override fun getTicksFlow(symbol: String): Flow<PriceTick> {
        return tickFlows.getOrPut(symbol) {
            MutableSharedFlow(replay = 1, extraBufferCapacity = 16)
        }.asSharedFlow()
    }

    override fun getCandles(symbol: String, timeframeSeconds: Int, count: Int): List<Candle> {
        val cached = candleCaches[symbol] ?: emptyList()
        if (cached.isEmpty()) {
            val initial = getCurrentPrice(symbol)
            generateInitialCandles(symbol, initial)
            return candleCaches[symbol]?.takeLast(count) ?: emptyList()
        }

        // Aggregate if needed or return mapped interval
        return cached.takeLast(count)
    }

    private fun getVolatilityForSymbol(symbol: String, price: Double): Double {
        return when {
            symbol.startsWith("BTC") -> price * 0.0004
            symbol.startsWith("ETH") -> price * 0.0005
            symbol.startsWith("SOL") -> price * 0.0008
            symbol.startsWith("XAU") -> price * 0.0002
            symbol.contains("JPY") -> 0.04
            else -> 0.00015 // Standard Forex pip noise
        }
    }

    private fun generateInitialCandles(symbol: String, basePrice: Double) {
        val list = mutableListOf<Candle>()
        var current = basePrice
        val now = System.currentTimeMillis()
        val intervalMs = 5000L // 5-second baseline candles

        val count = 80
        val startTime = now - (count * intervalMs)

        for (i in 0 until count) {
            val candleTime = startTime + (i * intervalMs)
            val vol = getVolatilityForSymbol(symbol, current) * 1.5
            val open = current
            val change1 = (Random.nextDouble() - 0.495) * vol
            val change2 = (Random.nextDouble() - 0.495) * vol
            val close = (open + change1).coerceAtLeast(0.00001)
            val high = maxOf(open, close) + Random.nextDouble() * vol * 0.5
            val low = minOf(open, close) - Random.nextDouble() * vol * 0.5
            val volume = Random.nextDouble(5.0, 50.0)

            list.add(Candle(candleTime, open, high, low, close, volume))
            current = close
        }
        candleCaches[symbol] = list
        assetPrices[symbol] = current
    }

    private fun updateCandleCache(symbol: String, newPrice: Double, timestamp: Long) {
        val list = candleCaches[symbol] ?: return
        if (list.isEmpty()) return

        val lastCandle = list.last()
        val candleDurationMs = 5000L

        if (timestamp - lastCandle.timestamp < candleDurationMs) {
            // Update current active candle
            val updated = lastCandle.copy(
                high = maxOf(lastCandle.high, newPrice),
                low = minOf(lastCandle.low, newPrice),
                close = newPrice,
                volume = lastCandle.volume + 1.0
            )
            list[list.lastIndex] = updated
        } else {
            // Form new candle
            val newCandle = Candle(
                timestamp = timestamp,
                open = lastCandle.close,
                high = maxOf(lastCandle.close, newPrice),
                low = minOf(lastCandle.close, newPrice),
                close = newPrice,
                volume = 1.0
            )
            list.add(newCandle)
            if (list.size > 200) {
                list.removeAt(0)
            }
        }
    }
}
