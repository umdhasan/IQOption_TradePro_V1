package com.example.network.api

import com.example.network.model.OpenForexRatesResponse
import retrofit2.http.GET
import retrofit2.http.Path

interface OpenForexApiService {

    @GET("v6/latest/{base}")
    suspend fun getLatestForexRates(
        @Path("base") baseCurrency: String = "USD"
    ): OpenForexRatesResponse
}
