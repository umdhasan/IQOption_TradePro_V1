package com.example.network

import com.example.model.Candle
import com.example.network.model.FinnhubQuoteResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class FinancialMarketRepository(
    private val retrofitClient: FinancialRetrofitClient = FinancialRetrofitClient
) {
    // Gracefully reads FINNHUB_API_KEY from BuildConfig if injected by AI Studio secrets panel
    private val finnhubApiKey: String?
        get() = runCatching {
            val field = Class.forName("com.example.BuildConfig").getField("FINNHUB_API_KEY")
            val value = field.get(null) as? String
            if (value.isNullOrBlank() || value.startsWith("MY_")) null else value
        }.getOrNull()

    val isFinnhubConfigured: Boolean
        get() = !finnhubApiKey.isNullOrBlank()

    /**
     * Fetches real-time stock quote from Finnhub via Retrofit.
     */
    suspend fun fetchStockQuote(symbol: String): FinnhubQuoteResponse? {
        val key = finnhubApiKey ?: return null
        return withContext(Dispatchers.IO) {
            runCatching {
                retrofitClient.finnhubApi.getQuote(symbol = symbol, token = key)
            }.getOrNull()
        }
    }

    /**
     * Fetches live world forex rates from OpenForex API via Retrofit.
     */
    suspend fun fetchForexRates(): Map<String, Double> {
        return withContext(Dispatchers.IO) {
            runCatching {
                val response = retrofitClient.openForexApi.getLatestForexRates("USD")
                val rates = response.rates ?: emptyMap()
                val converted = mutableMapOf<String, Double>()

                val eur = rates["EUR"] ?: 0.0
                if (eur > 0) converted["EUR/USD"] = 1.0 / eur

                val gbp = rates["GBP"] ?: 0.0
                if (gbp > 0) converted["GBP/USD"] = 1.0 / gbp

                val jpy = rates["JPY"] ?: 0.0
                if (jpy > 0) {
                    converted["USD/JPY"] = jpy
                    if (gbp > 0) converted["GBP/JPY"] = (1.0 / gbp) * jpy
                }

                val aud = rates["AUD"] ?: 0.0
                if (aud > 0) converted["AUD/USD"] = 1.0 / aud

                val cad = rates["CAD"] ?: 0.0
                if (cad > 0) converted["USD/CAD"] = cad

                val chf = rates["CHF"] ?: 0.0
                if (chf > 0) converted["USD/CHF"] = chf

                val nzd = rates["NZD"] ?: 0.0
                if (nzd > 0) converted["NZD/USD"] = 1.0 / nzd

                if (eur > 0 && gbp > 0) {
                    converted["EUR/GBP"] = gbp / eur
                }

                val mxn = rates["MXN"] ?: 0.0
                if (mxn > 0) converted["USD/MXN"] = mxn

                converted
            }.getOrDefault(emptyMap())
        }
    }

    /**
     * Fetches live crypto prices via Retrofit from Binance market API.
     */
    suspend fun fetchCryptoPrices(): Map<String, Double> {
        return withContext(Dispatchers.IO) {
            runCatching {
                val symbols = """["BTCUSDT","ETHUSDT","SOLUSDT"]"""
                val items = retrofitClient.binanceApi.get24HrTickers(symbols)
                val map = mutableMapOf<String, Double>()
                items.forEach { item ->
                    val price = item.lastPrice?.toDoubleOrNull() ?: item.price?.toDoubleOrNull()
                    if (price != null) {
                        when (item.symbol) {
                            "BTCUSDT" -> map["BTC/USD"] = price
                            "ETHUSDT" -> map["ETH/USD"] = price
                            "SOLUSDT" -> map["SOL/USD"] = price
                        }
                    }
                }
                map
            }.getOrDefault(emptyMap())
        }
    }

    /**
     * Fetches real 1m candlestick history for crypto via Retrofit.
     */
    suspend fun fetchCryptoKlines(symbol: String, limit: Int = 60): List<Candle> {
        return withContext(Dispatchers.IO) {
            runCatching {
                val binanceSym = when (symbol) {
                    "BTC/USD" -> "BTCUSDT"
                    "ETH/USD" -> "ETHUSDT"
                    "SOL/USD" -> "SOLUSDT"
                    else -> "BTCUSDT"
                }
                val raw = retrofitClient.binanceApi.getKlines(symbol = binanceSym, interval = "1m", limit = limit)
                raw.mapNotNull { row ->
                    if (row.size >= 6) {
                        val timestamp = (row[0] as? Number)?.toLong() ?: return@mapNotNull null
                        val open = (row[1] as? String)?.toDoubleOrNull() ?: return@mapNotNull null
                        val high = (row[2] as? String)?.toDoubleOrNull() ?: return@mapNotNull null
                        val low = (row[3] as? String)?.toDoubleOrNull() ?: return@mapNotNull null
                        val close = (row[4] as? String)?.toDoubleOrNull() ?: return@mapNotNull null
                        val volume = (row[5] as? String)?.toDoubleOrNull() ?: 1.0
                        Candle(timestamp, open, high, low, close, volume)
                    } else null
                }
            }.getOrDefault(emptyList())
        }
    }
}
