package com.example.network.api

import com.example.network.model.BinanceTickerDto
import retrofit2.http.GET
import retrofit2.http.Query

interface BinanceMarketApiService {

    @GET("api/v3/ticker/24hr")
    suspend fun get24HrTickers(
        @Query("symbols") symbolsJsonArray: String
    ): List<BinanceTickerDto>

    @GET("api/v3/klines")
    suspend fun getKlines(
        @Query("symbol") symbol: String,
        @Query("interval") interval: String = "1m",
        @Query("limit") limit: Int = 60
    ): List<List<Any>>
}
