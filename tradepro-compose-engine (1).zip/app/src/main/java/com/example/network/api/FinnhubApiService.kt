package com.example.network.api

import com.example.network.model.FinnhubCandlesResponse
import com.example.network.model.FinnhubQuoteResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface FinnhubApiService {

    @GET("api/v1/quote")
    suspend fun getQuote(
        @Query("symbol") symbol: String,
        @Query("token") token: String
    ): FinnhubQuoteResponse

    @GET("api/v1/stock/candle")
    suspend fun getStockCandles(
        @Query("symbol") symbol: String,
        @Query("resolution") resolution: String,
        @Query("from") from: Long,
        @Query("to") to: Long,
        @Query("token") token: String
    ): FinnhubCandlesResponse

    @GET("api/v1/crypto/candle")
    suspend fun getCryptoCandles(
        @Query("symbol") symbol: String,
        @Query("resolution") resolution: String,
        @Query("from") from: Long,
        @Query("to") to: Long,
        @Query("token") token: String
    ): FinnhubCandlesResponse
}
