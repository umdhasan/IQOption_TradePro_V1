package com.example.network.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class FinnhubQuoteResponse(
    @Json(name = "c") val currentPrice: Double? = null,
    @Json(name = "d") val change: Double? = null,
    @Json(name = "dp") val percentChange: Double? = null,
    @Json(name = "h") val highPrice: Double? = null,
    @Json(name = "l") val lowPrice: Double? = null,
    @Json(name = "o") val openPrice: Double? = null,
    @Json(name = "pc") val previousClose: Double? = null,
    @Json(name = "t") val timestamp: Long? = null
)

@JsonClass(generateAdapter = true)
data class FinnhubCandlesResponse(
    @Json(name = "c") val closePrices: List<Double>? = null,
    @Json(name = "h") val highPrices: List<Double>? = null,
    @Json(name = "l") val lowPrices: List<Double>? = null,
    @Json(name = "o") val openPrices: List<Double>? = null,
    @Json(name = "s") val status: String? = null,
    @Json(name = "t") val timestamps: List<Long>? = null,
    @Json(name = "v") val volumes: List<Double>? = null
)

@JsonClass(generateAdapter = true)
data class OpenForexRatesResponse(
    @Json(name = "result") val result: String? = null,
    @Json(name = "base_code") val baseCode: String? = null,
    @Json(name = "time_last_update_unix") val lastUpdateUnix: Long? = null,
    @Json(name = "rates") val rates: Map<String, Double>? = null
)

@JsonClass(generateAdapter = true)
data class BinanceTickerDto(
    @Json(name = "symbol") val symbol: String,
    @Json(name = "lastPrice") val lastPrice: String? = null,
    @Json(name = "price") val price: String? = null,
    @Json(name = "priceChangePercent") val priceChangePercent: String? = null,
    @Json(name = "highPrice") val highPrice: String? = null,
    @Json(name = "lowPrice") val lowPrice: String? = null,
    @Json(name = "openPrice") val openPrice: String? = null
)
