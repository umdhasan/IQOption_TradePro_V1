# IQOption TradePro - Android Trading Terminal

A high-performance, native Android trading terminal built with **Kotlin** and **Jetpack Compose**.

## Features

### 1. Market Products
- **Digital**: High-payout options trading with strict strike targets and countdown expirations.
- **Binary**: Classic CALL / PUT binary options with up to 95% simulated payout.
- **Forex**: Multi-asset currency pairs (EUR/USD, GBP/USD, USD/JPY, AUD/USD, etc.) with real-time simulated spreads and pip dynamics.
- **Blitz**: Ultra-fast scalping options with 5s, 15s, and 30s turbo expirations.

### 2. Simulated / Demo Data Transparency
- Prominently displays **"SIMULATED / DEMO DATA"** badge across all charts, market tabs, and trade terminal screens.
- No live broker connection or real money risk without verified user credentials.
- Instant Demo Balance Reset feature to easily restart trading simulations with $10,000 virtual equity.

### 3. Deterministic Trade Settlement Engine
- **TradeSettlementEngine**: Strictly evaluates CALL/PUT outcome at expiration against exact entry price.
  - **WIN**: Target reached in directional prediction (`payout = investment + (investment * payoutRate)`).
  - **LOSS**: Prediction reversed (`payout = 0`).
  - **TIE / ATM (At The Money)**: Exit price exactly equals entry price -> 100% investment refund.

### 4. Technical Analysis & Signal Bot
- Interactive Candlestick (5s, 15s, 30s, 1m, 2m, 5m timeframes) and Area chart views.
- Real-time technical indicators: **SMA (Simple Moving Average)**, **EMA (Exponential Moving Average)**, **RSI (Relative Strength Index)**, **MACD**, and **Bollinger Bands**.
- Automated Signal Engine scanning for market momentum, oversold/overbought conditions, and trend reversals.

### 5. Local Persistence with Room
- Local storage for Trade History, Price Alerts, and Generated Signals.
- Zero external broken dependencies or hardcoded keys.

## GitHub Actions & Building
- CI Workflow located at `.github/workflows/android-apk.yml` builds the Debug APK and uploads it as an artifact on every push.
